# Sabor Urbano — versão 2 (identidade vermelho e amarelo)

Projeto inicial para a vitrine de cardápios de Manoel Urbano, Acre.

## O que está neste pacote
- Interface responsiva com identidade visual vermelho/amarelo.
- Busca, categorias, destaques e botões de pedido por WhatsApp.
- Painel local de demonstração para cadastrar, editar e excluir vendedores.
- Manifest, ícone e service worker para testar instalação como PWA.
- `supabase/schema.sql`: primeira estrutura de banco compartilhado e regras RLS.
- Guia passo a passo para preparar a versão real.

## Testar agora
1. Extraia o ZIP.
2. Abra `index.html` para ver a interface. Para testar instalação PWA, publique em HTTPS.
3. Toque em Administração e use a senha demonstrativa `mudar123`.
4. Cadastre dados fictícios e teste os cartões. Dados ficam só no navegador atual.

## Importante: ainda não é produção
O painel incluído nesta pasta é APENAS uma demonstração. A senha está no JavaScript e os dados ficam no armazenamento local do navegador. Não publique esse painel como área administrativa real. O SQL do Supabase é o ponto de partida do banco e das regras de acesso; a interface ainda precisa ser conectada ao Supabase Auth e às tabelas antes de operar com vendedores reais.

## Próximo passo: banco compartilhado com Supabase
É mais fácil fazer a configuração inicial pelo navegador do celular em modo “site para computador”; em algumas telas, computador é mais confortável.

1. Abra `https://supabase.com` e crie uma conta/projeto chamado `sabor-urbano`.
2. Guarde a senha do banco em um gerenciador de senhas. Não envie essa senha no chat.
3. No painel do projeto, abra **SQL Editor** → **New query**.
4. Abra o arquivo `supabase/schema.sql`, copie todo o conteúdo e cole no SQL Editor. Execute.
5. Em **Authentication**, crie seu usuário administrador com seu e-mail e uma senha forte.
6. Encontre o UUID desse usuário na área de usuários de Authentication.
7. No SQL Editor, execute o comando abaixo substituindo o UUID pelo seu:
   `insert into public.profiles (id, display_name, role) values ('SEU-UUID-AQUI', 'Administrador Sabor Urbano', 'admin');`
8. Não crie cadastro público de administradores. Só você deve receber acesso de admin.
9. Configure armazenamento de imagens em um bucket próprio e limite formatos/tamanho dos arquivos.
10. A próxima etapa de desenvolvimento deve conectar o site às tabelas e usar o login do Supabase Auth. As políticas RLS do SQL são uma camada de proteção, mas precisam ser testadas antes de lançar.

## Como funciona o destaque pago
Modelo inicial sugerido:
- Cardápio normal: gratuito.
- Destaque de 7 dias: preço que você define.
- Destaque de 30 dias: preço que você define.
- Você confirma o pagamento manualmente e marca a campanha como `paid`, com data de início e fim.
- Só campanhas pagas e dentro do prazo devem aparecer como destaque.
- No protótipo atual, o botão “destaque” é só visual: não cobra nem valida pagamento. Não anuncie destaque automático até a integração segura existir.

Para a primeira versão, é mais simples aceitar pagamento manual via Pix e conferir o comprovante. Não armazene dados de cartão. Se futuramente quiser automatizar, use um provedor de pagamentos e valide a confirmação no servidor, nunca confiando apenas no navegador.

## Publicar e instalar no Android
1. Escolha hospedagem HTTPS estática (ex.: Cloudflare Pages, Netlify ou GitHub Pages).
2. Envie os arquivos do projeto para a hospedagem.
3. Teste a URL no Android, os links do WhatsApp e a busca.
4. Em Chrome Android, abra o menu e escolha “Instalar app” ou “Adicionar à tela inicial” quando disponível.
5. A versão PWA instalada não é o mesmo que um app publicado na Play Store. Depois de validar o negócio, pode-se empacotar/desenvolver a versão Android nativa.

## Checklist antes de anunciar
- [ ] Trocar os cardápios fictícios por negócios que autorizaram o cadastro.
- [ ] Preencher `ADMIN_PHONE` em `app.js` com seu WhatsApp (só números, ex.: `5568999999999`).
- [ ] Conectar o frontend ao Supabase Auth e banco; remover senha de demonstração.
- [ ] Testar permissões de visitante e administrador em dois aparelhos.
- [ ] Adicionar política de privacidade e termos de uso.
- [ ] Explicar aos vendedores preços, prazo e regras dos destaques.
- [ ] Fazer cópia de segurança dos dados.
- [ ] Só então divulgar publicamente.

## Arquivos
- `index.html` — estrutura da página.
- `styles.css` — visual e responsividade.
- `app.js` — busca, WhatsApp e painel de demonstração local.
- `manifest.json` e `sw.js` — suporte básico a PWA.
- `assets/icon.svg` — ícone inicial.
- `supabase/schema.sql` — estrutura inicial do banco e políticas de acesso.
