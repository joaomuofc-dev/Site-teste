-- Sabor Urbano: schema inicial para Supabase (PostgreSQL)
-- Execute no SQL Editor do projeto Supabase depois de criar o projeto.
-- Princípio: visitantes leem apenas estabelecimentos publicados e produtos ativos.
-- Apenas administradores autenticados podem inserir/editar/excluir.
-- Nunca coloque a chave service_role no navegador.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role text not null default 'admin' check (role in ('admin'))
);

create table if not exists public.restaurants (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 100),
  slug text not null unique,
  category text not null,
  description text not null default '',
  image_url text,
  whatsapp text not null,
  hours text not null default '',
  address_or_delivery text not null default '',
  main_product text not null default '',
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 100),
  description text not null default '',
  price_cents integer not null check (price_cents >= 0),
  image_url text,
  is_available boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.featured_campaigns (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  starts_at timestamptz not null default now(),
  ends_at timestamptz not null,
  amount_cents integer not null check (amount_cents >= 0),
  payment_status text not null default 'pending' check (payment_status in ('pending','paid','cancelled','refunded')),
  payment_reference text,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create index if not exists restaurants_published_idx on public.restaurants (is_published, name);
create index if not exists products_restaurant_idx on public.products (restaurant_id, is_available, sort_order);
create index if not exists featured_dates_idx on public.featured_campaigns (starts_at, ends_at, payment_status);

alter table public.profiles enable row level security;
alter table public.restaurants enable row level security;
alter table public.products enable row level security;
alter table public.featured_campaigns enable row level security;

-- Helper: only a user with a profile row can administer content.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin') $$;

-- Public can read published restaurants. Admin can read all.
drop policy if exists "Public reads published restaurants" on public.restaurants;
create policy "Public reads published restaurants" on public.restaurants
for select using (is_published = true or public.is_admin());

drop policy if exists "Admin inserts restaurants" on public.restaurants;
create policy "Admin inserts restaurants" on public.restaurants
for insert to authenticated with check (public.is_admin());

drop policy if exists "Admin updates restaurants" on public.restaurants;
create policy "Admin updates restaurants" on public.restaurants
for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "Admin deletes restaurants" on public.restaurants;
create policy "Admin deletes restaurants" on public.restaurants
for delete to authenticated using (public.is_admin());

drop policy if exists "Public reads available products of published restaurants" on public.products;
create policy "Public reads available products of published restaurants" on public.products
for select using (
  is_available = true and exists (
    select 1 from public.restaurants r where r.id = restaurant_id and r.is_published = true
  ) or public.is_admin()
);

drop policy if exists "Admin manages products" on public.products;
create policy "Admin manages products" on public.products
for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Campaigns are private to admins. A later secure view/function can expose only
-- the fact that a paid campaign is currently active to the public storefront.
drop policy if exists "Admin reads campaigns" on public.featured_campaigns;
create policy "Admin reads campaigns" on public.featured_campaigns
for select to authenticated using (public.is_admin());

drop policy if exists "Admin manages campaigns" on public.featured_campaigns;
create policy "Admin manages campaigns" on public.featured_campaigns
for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "Admin reads own profile" on public.profiles;
create policy "Admin reads own profile" on public.profiles
for select to authenticated using (id = auth.uid() and public.is_admin());

-- Do NOT allow users to self-assign an admin profile. Create the first profile
-- only after creating your own account, from the SQL Editor as project owner:
-- insert into public.profiles (id, display_name, role)
-- values ('YOUR_AUTH_USER_UUID', 'Administrador Sabor Urbano', 'admin');
